#Up
Flying is not possible, but jumping is not possible. Up, a game created that updates weekly. See below how to play:
<img src=https://img.shields.io/badge/to_up-8A2BE2>
## HOW TO PLAY
use the arrow keys, of course. And reach as high as possible (try to beat the game (: )

## requires...

1. localhost server for sprites to be made
2. computer

## explore:

* create your platforms

## license

in license.txt

