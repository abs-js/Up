let p;
class MainMenu extends Phaser.Scene {
    constructor() {
        super({ key: 'Menu' });
    }

    preload() {
        this.load.image('sky', 'assets/images/sky.png');
        this.load.image('platform', 'assets/images/platform.png');
        this.load.image('box', 'assets/images/box.png');
        this.load.spritesheet('player', 'assets/images/player.png', { frameWidth: 32, frameHeight: 48 });
    }

    create() {
        this.sky = this.add.image(400, 300, 'sky');

        this.add.text(400, 300, 'press enter', {
            fontSize: "24px"
        }).setOrigin(0.5, 0.5);

        this.add.text(400, 350, 'press f1 to get help', {
            fontSize: "24px"
        }).setOrigin(0.5, 0.5);

        this.add.text(400, 200, 'up', {
            fontSize: "50px"
        }).setOrigin(0.5, 0.5);

        this.add.text(600, 490, 'Up, Artur bernardo', {
            fontSize: "10px"
        }).setOrigin(0.5, 0.5);

        this.enterKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ENTER);
        this.space = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
        this.f1 = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.F1);

        this.platforms = this.physics.add.staticGroup();
        this.platforms.create(400, 450, 'platform').setScale(2, 0.5).refreshBody();

        this.player = this.physics.add.sprite(400, 400, 'player');
        this.physics.add.collider(this.player, this.platforms);

        this.cursors = this.input.keyboard.createCursorKeys();

        this.cameras.main.flash(2000, 0xffffff);

        this.boxes = this.physics.add.group();
        this.boxes.create(250, 100, 'box').refreshBody();

        this.physics.add.collider(this.boxes, this.platforms);
        this.physics.add.collider(this.boxes, this.player);
    }

    update() {
        this.handlePlayerMovement();
        this.checkPlayerPosition();

        if (this.enterKey.isDown) {
            this.scene.start('GameScene');
        }

        if (this.f1.isDown) {
            this.scene.start('howtoplay');
        }

        this.boxes.getChildren().forEach(function(box) {
            box.setVelocityX(0);
        });
    }

    checkPlayerPosition() {
        if (this.player.x > 800) {
            this.player.x = 10;
        } else if (this.player.x < 0) {
            this.player.x = 790;
        }
    }

    handlePlayerMovement() {
        this.player.setVelocityX(160);
            if (this.player.body.touching.down) {
                this.player.anims.play('right', true);
            } else {
                this.player.anims.play('flyright', true);
            }

        if (this.player.x > 600 && this.player.body.touching.down) {
            this.player.setVelocityY(-330);
        }
    }
}

class howtoplay extends Phaser.Scene {
    constructor() {
        super({ key: 'howtoplay' });
    }

    preload() {
        this.load.image('sky', 'assets/images/sky.png');
    }

    create() {
        this.sky = this.add.image(400, 300, 'sky');

        this.add.text(400, 100, 'How to Play:', {
            fontSize: '32px',
            fill: '#ffffff'
        }).setOrigin(0.5, 0.5);

        this.add.text(400, 200, 'Use ARROW keys to move.\nSPACE to jump.', {
            fontSize: '24px',
            fill: '#ffffff'
        }).setOrigin(0.5, 0.5);

        this.add.text(400, 300, 'push BOXES, they can HELP you.\ngo as HIGH as possible.', {
            fontSize: '24px',
            fill: '#ffffff'
        }).setOrigin(0.5, 0.5);

        this.add.text(400, 400, 'GO to one SIDE of the SCREEN to EXIT on the OTHER.\nno HIT your HEAD!', {
            fontSize: '24px',
            fill: '#ffffff'
        }).setOrigin(0.5, 0.5);

        this.add.text(400, 480, 'Press ENTER to return to Main Menu', {
            fontSize: '12px',
            fill: '#ffffff'
        }).setOrigin(0.5, 0.5);

        this.enterKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ENTER);
        this.f1 = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.F1);
        this.cameras.main.flash(2000, 0xffffff);
    }

    update() {
        if (this.enterKey.isDown) {
            this.scene.start('Menu');
        }

        if (this.f1.isDown) {
            this.scene.start('Menu');
        }
    }
}

class GameScene extends Phaser.Scene {
    constructor() {
        super({ key: 'GameScene' });
    }

    preload() {
        this.load.image('sky', 'assets/images/sky.png');
        this.load.image('platform', 'assets/images/platform.png');
        this.load.spritesheet('player', 'assets/images/player.png', { frameWidth: 32, frameHeight: 48 });
        this.load.spritesheet('destroy', 'assets/images/destroy.png', { frameWidth: 32, frameHeight: 48 });
        this.load.image('box', 'assets/images/box.png');
    }

    create() {
        this.sky = this.add.image(400, 300, 'sky');

        this.platforms = this.physics.add.staticGroup();
        this.createPlatforms();

        this.player = this.physics.add.sprite(100, 450, 'player');
        p = this.player;

        this.boxes = this.physics.add.group();
        this.boxes.create(250, -740, 'box').refreshBody();
        this.boxes.create(400, -940, 'box').refreshBody();
        this.boxes.create(600, -940, 'box').refreshBody();
        this.boxes.create(155, -1400, 'box').refreshBody();

        this.physics.add.collider(this.player, this.platforms);
        this.physics.add.collider(this.player, this.boxes);
        this.physics.add.collider(this.boxes, this.platforms);
        this.physics.add.collider(this.boxes, this.boxes);

        this.cursors = this.input.keyboard.createCursorKeys();
        this.space = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
        this.esc = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ESC);

        this.cameras.main.startFollow(this.player);
        this.cameras.main.setBounds(0, -Infinity, 0, Infinity);
        this.cameras.main.flash(2000, 0xffffff);

        this.gameover = false;
    }

    update() {
        if (!this.gameover) {
            this.handlePlayerMovement();
            this.checkPlayerPosition();
        }

        if (this.player.body.touching.up) {
            this.handleGameOver();
            this.cameras.main.shake(300, 0.01);
        }

        if (this.esc.isDown) {
            this.scene.switch('Menu')
        }

        this.updateBoxes();
        this.sky.y = this.player.y;
    }

    createPlatforms() {
        const platformConfig = [
            { x: 400, y: 590, scale: { x: 1.6, y: 1 } },
            { x: 550, y: 400, scale: { x: 0.5, y: 0.5 } },
            { x: 200, y: 325, scale: { x: 0.5, y: 0.5 } },
            { x: 400, y: 50, scale: { x: 0.1, y: 3.4 } },
            { x: 575, y: 170, scale: { x: 0.8, y: 0.5 } },
            { x: 500, y: 0, scale: { x: 0.25, y: 0.5 } },
            { x: 300, y: -160, scale: { x: 0.5, y: 0.5 } },
            { x: 600, y: -360, scale: { x: 0.5, y: 0.5 } },
            { x: 100, y: -260, scale: { x: 0.5, y: 0.5 } },
            { x: 750, y: -460, scale: { x: 0.1, y: 3.5 } },
            { x: 600, y: -500, scale: { x: 0.5, y: 0.5 } },
            { x: 200, y: -700, scale: { x: 0.5, y: 0.5 } },
            { x: 400, y: -900, scale: { x: 0.7, y: 0.5 } },
            { x: 600, y: -1100, scale: { x: 0.5, y: 0.5 } },
            { x: 100, y: -1200, scale: { x: 0.5, y: 0.5 } },
            { x: 200, y: -1290, scale: { x: 0.1, y: 3.3 } },
            { x: 600, y: -1500, scale: { x: 0.5, y: 0.5 } },
            { x: 200, y: -1650, scale: { x: 0.5, y: 0.5 } },
            { x: 600, y: -1800, scale: { x: 0.5, y: 0.5 } },
            { x: 300, y: -1950, scale: { x: 0.75, y: 0.5 } }
        ];
        platformConfig.forEach(config => {
            this.platforms.create(config.x, config.y, 'platform').setScale(config.scale.x, config.scale.y).refreshBody();
        });
    }

    handlePlayerMovement() {
        if (this.cursors.left.isDown) {
            this.player.setVelocityX(-160);
            if (this.player.body.touching.down) {
                this.player.anims.play('left', true);
            } else {
                this.player.anims.play('flyleft', true);
            }
            this.left = true;
        } else if (this.cursors.right.isDown) {
            this.player.setVelocityX(160);
            if (this.player.body.touching.down) {
                this.player.anims.play('right', true);
            } else {
                this.player.anims.play('flyright', true);
            }
            this.left = false;
        } else {
            this.player.setVelocityX(0);
        }

        if (!this.cursors.right.isDown && !this.cursors.left.isDown && this.player.body.touching.down) {
            this.player.anims.play(this.left === true ? 'stpleft' : 'stpright');
        } else if (!this.cursors.right.isDown && !this.cursors.left.isDown && !this.player.body.touching.down) {
            this.player.anims.play(this.left === true ? 'flyleft' : 'flyright');
        }

        if ((this.space.isDown || this.cursors.up.isDown) && this.player.body.touching.down) {
            this.player.setVelocityY(-330);
        }

        if (this.player.y <= -2100) {
            this.add.text(400, -2100, 'erased de game.', {
                fontSize: '24px',
                fill: '#ffffff'
            }).setOrigin(0.5, 0.5);
        }
    }

    checkPlayerPosition() {
        if (this.player.x > 800) {
            this.player.x = 10;
        } else if (this.player.x < 0) {
            this.player.x = 790;
        }
    }

    handleGameOver() {
        this.player.anims.play('destroy');
        this.add.text(250, this.player.y, 'Game OveR', {
            fill: 'red',
            fontSize: "50px"
        });
        this.gameover = true;
        this.player.on('animationcomplete-destroy', () => {
            this.player.disableBody(true, true);
        });
    }

    updateBoxes() {
        this.boxes.getChildren().forEach(function(box) {
                box.setVelocityX(0);
        });
    }
}

class boot extends Phaser.Scene {
    constructor() {
        super({ key: 'boot' });
    }

    preload() {
        this.load.spritesheet('player', 'assets/images/player.png', { frameWidth: 32, frameHeight: 48 });
        this.load.spritesheet('destroy', 'assets/images/destroy.png', { frameWidth: 32, frameHeight: 48 });
    }

    create() {
        this.createAnimations();
        this.scene.start('Menu');
    }

    createAnimations() {
        this.anims.create({
            key: 'left',
            frames: this.anims.generateFrameNumbers('player', { start: 3, end: 0 }),
            frameRate: 10,
            repeat: 0
        });

        this.anims.create({
            key: 'stpleft',
            frames: [{ key: 'player', frame: 2 }],
            frameRate: 10,
            repeat: 0
        });

        this.anims.create({
            key: 'turn',
            frames: [{ key: 'player', frame: 4 }],
            frameRate: 20
        });

        this.anims.create({
            key: 'right',
            frames: this.anims.generateFrameNumbers('player', { start: 5, end: 8 }),
            frameRate: 10,
            repeat: 0
        });

        this.anims.create({
            key: 'stpright',
            frames: [{ key: 'player', frame: 6 }],
            frameRate: 10,
            repeat: 0
        });

        this.anims.create({
            key: 'flyleft',
            frames: [{ key: 'player', frame: 9 }],
            frameRate: 10,
            repeat: -1
        });

        this.anims.create({
            key: 'flyright',
            frames: [{ key: 'player', frame: 10 }],
            frameRate: 10,
            repeat: -1
        });

        this.anims.create({
            key: 'destroy',
            frames: this.anims.generateFrameNumbers('destroy', { start: 0, end: 3 }),
            frameRate: 7,
            repeat: 0
        });
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const config = {
        type: Phaser.AUTO,
        width: 800,
        height: 500,
        physics: {
            default: 'arcade',
            arcade: {
                gravity: { y: 300 },
                debug: false
            }
        },
        scene: [boot, MainMenu, howtoplay, GameScene],
        fps: { forceSetState: false, target: 60 }
    };

    const game = new Phaser.Game(config);
});
